import streamlit as st
import mysql.connector
import pandas as pd
from datetime import datetime
import streamlit.components.v1 as components

# 앱 제목과 페이지 설정
st.set_page_config(
    page_title="식당 커뮤니티 DB 관리", 
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        'About': "식당 커뮤니티 관리 애플리케이션입니다."
    }
)

# CSS 스타일 정의
st.markdown("""
<style>
    /* 전체 폰트 및 기본 스타일 */
    @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;700&display=swap');
    
    * {
        font-family: 'Noto Sans KR', sans-serif;
    }
    
    /* 헤더 스타일 */
    .main-header {
        background: linear-gradient(to right, #56ab2f, #a8e063);
        color: white;
        padding: 1.5rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    /* 카드 스타일 */
    .card {
        background-color: white;
        border-radius: 10px;
        padding: 1.5rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        margin-bottom: 1rem;
        transition: transform 0.3s ease;
    }
    
    .card:hover {
        transform: translateY(-5px);
    }
    
    /* 버튼 스타일 */
    .stButton>button {
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 0.5rem 1rem;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .stButton>button:hover {
        background-color: #45a049;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }
    
    /* 폼 입력 필드 스타일 */
    input, textarea, select {
        border-radius: 5px !important;
        border: 1px solid #ddd !important;
    }
    
    /* 사이드바 스타일 */
    .css-1d391kg {
        background-color: #f8f9fa;
    }
    
    /* 모바일 최적화 */
    @media (max-width: 768px) {
        .main-header {
            padding: 1rem;
            font-size: 0.9rem;
        }
        
        .card {
            padding: 1rem;
        }
        
        /* 모바일에서 폰트 크기 조정 */
        h1 {
            font-size: 1.5rem !important;
        }
        
        h2 {
            font-size: 1.3rem !important;
        }
        
        h3 {
            font-size: 1.1rem !important;
        }
        
        p, li, label {
            font-size: 0.9rem !important;
        }
        
        /* 모바일에서 버튼 크기 조정 */
        .stButton>button {
            padding: 0.4rem 0.8rem;
            font-size: 0.8rem;
        }
        
        /* 테이블 스크롤 */
        .stDataFrame {
            overflow-x: auto;
        }
    }
    
    /* 태블릿 최적화 */
    @media (min-width: 769px) and (max-width: 1024px) {
        h1 {
            font-size: 1.8rem !important;
        }
        
        /* 태블릿에서 레이아웃 조정 */
        .row-container {
            flex-direction: column;
        }
    }
    
    /* 데이터프레임 스타일링 */
    .dataframe {
        border: none !important;
    }
    
    .dataframe td, .dataframe th {
        text-align: left !important;
        padding: 12px !important;
        border-bottom: 1px solid #f0f0f0 !important;
    }
    
    .dataframe th {
        background-color: #f8f9fa !important;
        font-weight: 500 !important;
    }
    
    .dataframe tr:hover {
        background-color: #f5f5f5 !important;
    }
    
    /* 성공, 오류, 경고 메시지 스타일 */
    .success-message {
        background-color: #d4edda;
        color: #155724;
        padding: 1rem;
        border-radius: 5px;
        margin: 1rem 0;
    }
    
    .error-message {
        background-color: #f8d7da;
        color: #721c24;
        padding: 1rem;
        border-radius: 5px;
        margin: 1rem 0;
    }
    
    .warning-message {
        background-color: #fff3cd;
        color: #856404;
        padding: 1rem;
        border-radius: 5px;
        margin: 1rem 0;
    }
    
    /* 글 내용 스타일 */
    .post-content {
        background-color: #f9f9f9;
        border-radius: 5px;
        padding: 1.5rem;
        margin-top: 1rem;
        line-height: 1.6;
    }
    
    /* 테이블 헤더 색상 */
    thead th {
        background-color: #4CAF50 !important;
        color: white !important;
    }
    
    /* 선택 강조 효과 */
    .selected {
        border-left: 4px solid #4CAF50;
        padding-left: 10px;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

# 헤더 영역 (반응형)
st.markdown('<div class="main-header"><h1>식당 커뮤니티 대시보드</h1></div>', unsafe_allow_html=True)

# 데이터베이스 연결 정보
try:
    # streamlit secrets에서 연결 정보 가져오기
    DB_CONFIG = {
        "host": st.secrets["db_host"],
        "port": int(st.secrets["db_port"]),
        "user": st.secrets["db_username"],
        "password": st.secrets["db_password"],
        "database": st.secrets["db_name"]
    }
except Exception as e:
    st.error("데이터베이스 연결 정보를 불러올 수 없습니다. Secrets 설정을 확인하세요.")
    st.stop()

# 데이터베이스 연결 함수
def connect_to_db():
    try:
        return mysql.connector.connect(
            host=DB_CONFIG["host"],
            port=DB_CONFIG["port"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            database=DB_CONFIG["database"]
        )
    except Exception as e:
        st.markdown(f'<div class="error-message">데이터베이스 연결 오류: {str(e)}</div>', unsafe_allow_html=True)
        return None

# 식당별 게시판 정보 (원본 테이블명과 표시명 매핑)
RESTAURANTS = {
    "jeongdam": "정담식당",  
    "shumouse": "슈마우스만찬찬", 
    "manna": "만나식당",  
    "dawafood": "다와푸드식당",     
    "qbee": "큐비식당"        
}

# 식당 아이콘 (이모티콘)
RESTAURANT_ICONS = {
    "jeongdam": "🍲",  
    "shumouse": "🍱", 
    "manna": "🍜",  
    "dawafood": "🍕",     
    "qbee": "🍔"        
}

# 사이드바 스타일링
st.sidebar.markdown("""
<div style="text-align: center; margin-bottom: 20px;">
    <h2 style="color: #4CAF50;">메뉴</h2>
</div>
""", unsafe_allow_html=True)

# 게시판 선택 (아이콘 추가)
st.sidebar.markdown('<h3>게시판 선택</h3>', unsafe_allow_html=True)
board_options = [f"{RESTAURANT_ICONS[key]} {value}" for key, value in RESTAURANTS.items()]
selected_board_index = st.sidebar.selectbox(
    "",
    range(len(board_options)),
    format_func=lambda i: board_options[i],
    label_visibility="collapsed"
)
board_type = list(RESTAURANTS.keys())[selected_board_index]

st.sidebar.markdown('<hr style="margin: 15px 0;">', unsafe_allow_html=True)

# 관리 기능 선택 (개선된 UI)
st.sidebar.markdown('<h3>관리 기능</h3>', unsafe_allow_html=True)
admin_options = ["📋 게시글 조회", "✏️ 게시글 추가", "🔄 게시글 수정", "🗑️ 게시글 삭제"]
selected_action_index = st.sidebar.radio(
    "",
    range(len(admin_options)),
    format_func=lambda i: admin_options[i],
    label_visibility="collapsed"
)
admin_actions = ["게시글 조회", "게시글 추가", "게시글 수정", "게시글 삭제"]
admin_action = admin_actions[selected_action_index]

# 반응형 레이아웃을 위한 화면 너비 감지
components.html(
    """
    <script>
        window.addEventListener('message', function(e) {
            if (e.data.type === 'streamlit:render') {
                const screenWidth = window.innerWidth;
                window.parent.postMessage({
                    type: 'streamlit:setComponentValue',
                    value: screenWidth
                }, '*');
            }
        });
    </script>
    """,
    height=0,
    key="screen_width"
)

# 테이블이 존재하는지 확인하고 없으면 생성하는 함수
def ensure_table_exists(table_name):
    try:
        conn = connect_to_db()
        if conn:
            cursor = conn.cursor()
            
            # 테이블 존재 여부 확인
            cursor.execute(f"SHOW TABLES LIKE '{table_name}'")
            result = cursor.fetchone()
            
            # 테이블이 없으면 생성
            if not result:
                create_table_sql = f"""
                CREATE TABLE {table_name} (
                    num INT NOT NULL AUTO_INCREMENT,
                    title CHAR(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                    name CHAR(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                    pass CHAR(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                    content TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
                    day CHAR(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
                    PRIMARY KEY(num)
                ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
                """
                cursor.execute(create_table_sql)
                conn.commit()
                st.markdown(f'<div class="success-message">"{RESTAURANTS[table_name]}" 테이블이 생성되었습니다!</div>', unsafe_allow_html=True)
            
            cursor.close()
            conn.close()
            return True
    except Exception as e:
        st.markdown(f'<div class="error-message">테이블 확인/생성 중 오류 발생: {str(e)}</div>', unsafe_allow_html=True)
        return False

# 선택된 게시판의 테이블 존재 확인
ensure_table_exists(board_type)

# 게시글 조회 기능
if admin_action == "게시글 조회":
    st.markdown(f'<h2>{RESTAURANT_ICONS[board_type]} {RESTAURANTS[board_type]} 게시글 목록</h2>', unsafe_allow_html=True)
    
    # 검색 기능 (반응형 레이아웃)
    search_col1, search_col2, search_col3 = st.columns([2, 5, 1])
    
    with search_col1:
        search_type_options = {
            "title": "제목",
            "content": "내용",
            "title_content": "제목+내용",
            "name": "작성자"
        }
        search_type = st.selectbox(
            "검색 조건", 
            options=list(search_type_options.keys()),
            format_func=lambda x: search_type_options[x]
        )
    
    with search_col2:
        search_keyword = st.text_input("검색어", placeholder="검색어를 입력하세요...")
    
    with search_col3:
        st.write("")
        search_button = st.button("🔍 검색")
    
    # 데이터 조회
    try:
        conn = connect_to_db()
        if conn:
            # 검색 조건 구성 (SQL 인젝션 방지)
            where_clause = ""
            params = []
            
            if search_keyword and search_button:
                if search_type == "title":
                    where_clause = " WHERE title LIKE %s"
                    params = [f"%{search_keyword}%"]
                elif search_type == "content":
                    where_clause = " WHERE content LIKE %s"
                    params = [f"%{search_keyword}%"]
                elif search_type == "title_content":
                    where_clause = " WHERE title LIKE %s OR content LIKE %s"
                    params = [f"%{search_keyword}%", f"%{search_keyword}%"]
                elif search_type == "name":
                    where_clause = " WHERE name LIKE %s"
                    params = [f"%{search_keyword}%"]
            
            # 쿼리 실행
            cursor = conn.cursor(dictionary=True)
            query = f"SELECT num, title, name, content, day FROM {board_type}{where_clause} ORDER BY num DESC"
            cursor.execute(query, params)
            results = cursor.fetchall()
            cursor.close()
            
            if results:
                # 결과를 데이터프레임으로 변환
                df = pd.DataFrame(results)
                
                # 내용 줄임말로 표시
                df['content'] = df['content'].str.slice(0, 50) + '...'
                
                # 스타일을 적용한 데이터프레임 표시
                st.markdown('<div class="card">', unsafe_allow_html=True)
                st.dataframe(
                    df,
                    use_container_width=True,
                    height=400,
                    column_config={
                        "num": "번호",
                        "title": "제목",
                        "name": "작성자",
                        "content": "내용 미리보기",
                        "day": "작성일"
                    },
                    hide_index=True,
                )
                st.markdown('</div>', unsafe_allow_html=True)
                
                # 선택한 게시글 상세보기
                st.markdown('<div class="card">', unsafe_allow_html=True)
                st.subheader("게시글 상세보기")
                selected_num = st.selectbox(
                    "상세보기할 게시글을 선택하세요:", 
                    options=df['num'].tolist(),
                    format_func=lambda x: f"#{x} - {df[df['num']==x]['title'].values[0]}"
                )
                
                if selected_num:
                    # 게시글 상세 내용 조회
                    cursor = conn.cursor(dictionary=True)
                    post_query = f"SELECT * FROM {board_type} WHERE num = %s"
                    cursor.execute(post_query, (selected_num,))
                    post = cursor.fetchone()
                    cursor.close()
                    
                    if post:
                        col1, col2 = st.columns([3, 1])
                        with col1:
                            st.markdown(f"<h3>{post['title']}</h3>", unsafe_allow_html=True)
                        with col2:
                            st.markdown(f"<p style='text-align:right;'><b>작성일:</b> {post['day']}</p>", unsafe_allow_html=True)
                        
                        st.markdown(f"<p><b>작성자:</b> {post['name']}</p>", unsafe_allow_html=True)
                        st.markdown("<hr>", unsafe_allow_html=True)
                        
                        # 내용을 카드 스타일로 표시
                        st.markdown(f'<div class="post-content">{post["content"].replace(chr(10), "<br>")}</div>', unsafe_allow_html=True)
                
                st.markdown('</div>', unsafe_allow_html=True)
            else:
                st.markdown('<div class="warning-message">게시글이 없습니다.</div>', unsafe_allow_html=True)
            
            conn.close()
    except Exception as e:
        st.markdown(f'<div class="error-message">데이터 조회 중 오류 발생: {str(e)}</div>', unsafe_allow_html=True)

# 게시글 추가 기능
elif admin_action == "게시글 추가":
    st.markdown(f'<h2>{RESTAURANT_ICONS[board_type]} {RESTAURANTS[board_type]} 게시글 추가</h2>', unsafe_allow_html=True)
    
    st.markdown('<div class="card">', unsafe_allow_html=True)
    with st.form("add_post_form", clear_on_submit=True):
        title = st.text_input("제목", placeholder="제목을 입력하세요")
        
        col1, col2 = st.columns(2)
        with col1:
            name = st.text_input("작성자", placeholder="이름을 입력하세요")
        with col2:
            password = st.text_input("비밀번호", type="password", placeholder="비밀번호를 입력하세요")
        
        content = st.text_area("내용", height=300, placeholder="내용을 입력하세요")
        
        today = datetime.now().strftime("%Y.%m.%d")
        
        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            submitted = st.form_submit_button("📝 게시글 등록")
        
        if submitted:
            if title and name and password and content:
                try:
                    conn = connect_to_db()
                    if conn:
                        cursor = conn.cursor()
                        
                        query = f"""
                        INSERT INTO {board_type} (title, name, pass, content, day)
                        VALUES (%s, %s, %s, %s, %s)
                        """
                        cursor.execute(query, (title, name, password, content, today))
                        conn.commit()
                        
                        st.markdown('<div class="success-message">게시글이 성공적으로 등록되었습니다!</div>', unsafe_allow_html=True)
                        
                        cursor.close()
                        conn.close()
                except Exception as e:
                    st.markdown(f'<div class="error-message">게시글 등록 중 오류 발생: {str(e)}</div>', unsafe_allow_html=True)
            else:
                st.markdown('<div class="warning-message">모든 필드를 채워주세요.</div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

# 게시글 수정 기능
elif admin_action == "게시글 수정":
    st.markdown(f'<h2>{RESTAURANT_ICONS[board_type]} {RESTAURANTS[board_type]} 게시글 수정</h2>', unsafe_allow_html=True)
    
    try:
        conn = connect_to_db()
        if conn:
            # 게시글 목록 가져오기
            cursor = conn.cursor(dictionary=True)
            query = f"SELECT num, title, name FROM {board_type} ORDER BY num DESC"
            cursor.execute(query)
            posts = cursor.fetchall()
            cursor.close()
            
            if posts:
                st.markdown('<div class="card">', unsafe_allow_html=True)
                
                # 게시글 선택
                post_options = {row['num']: f"#{row['num']} - {row['title']} (작성자: {row['name']})" for row in posts}
                selected_num = st.selectbox(
                    "수정할 게시글 선택:", 
                    options=list(post_options.keys()),
                    format_func=lambda x: post_options[x]
                )
                
                if selected_num:
                    # 게시글 데이터 가져오기
                    cursor = conn.cursor(dictionary=True)
                    post_query = f"SELECT * FROM {board_type} WHERE num = %s"
                    cursor.execute(post_query, (selected_num,))
                    post = cursor.fetchone()
                    cursor.close()
                    
                    # 수정 폼
                    with st.form("edit_post_form"):
                        title = st.text_input("제목", value=post['title'])
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            st.text_input("작성자", value=post['name'], disabled=True)
                        with col2:
                            password = st.text_input("비밀번호 확인", type="password", placeholder="비밀번호를 입력하세요")
                        
                        content = st.text_area("내용", value=post['content'], height=300)
                        
                        today = datetime.now().strftime("%Y.%m.%d")
                        
                        col1, col2, col3 = st.columns([1, 1, 1])
                        with col2:
                            submitted = st.form_submit_button("🔄 게시글 수정")
                        
                        if submitted:
                            if title and password and content:
                                # 비밀번호 확인
                                cursor = conn.cursor()
                                cursor.execute(f"SELECT pass FROM {board_type} WHERE num = %s", (selected_num,))
                                stored_password = cursor.fetchone()[0]
                                
                                if password == stored_password:
                                    # 게시글 수정
                                    update_query = f"""
                                    UPDATE {board_type} 
                                    SET title = %s, content = %s, day = %s
                                    WHERE num = %s
                                    """
                                    cursor.execute(update_query, (title, content, today, selected_num))
                                    conn.commit()
                                    
                                    st.markdown('<div class="success-message">게시글이 성공적으로 수정되었습니다!</div>', unsafe_allow_html=True)
                                else:
                                    st.markdown('<div class="error-message">비밀번호가 일치하지 않습니다.</div>', unsafe_allow_html=True)
                                
                                cursor.close()
                            else:
                                st.markdown('<div class="warning-message">모든 필드를 채워주세요.</div>', unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)
            else:
                st.markdown('<div class="warning-message">수정할 게시글이 없습니다.</div>', unsafe_allow_html=True)
            
            conn.close()
    except Exception as e:
        st.markdown(f'<div class="error-message">게시글 수정 중 오류 발생: {str(e)}</div>', unsafe_allow_html=True)

# 게시글 삭제 기능
elif admin_action == "게시글 삭제":
    st.markdown(f'<h2>{RESTAURANT_ICONS[board_type]} {RESTAURANTS[board_type]} 게시글 삭제</h2>', unsafe_allow_html=True)
    
    try:
        conn = connect_to_db()
        if conn:
            # 게시글 목록 가져오기
            cursor = conn.cursor(dictionary=True)
            query = f"SELECT num, title, name FROM {board_type} ORDER BY num DESC"
            cursor.execute(query)
            posts = cursor.fetchall()
            cursor.close()
            
            if posts:
                st.markdown('<div class="card">', unsafe_allow_html=True)
                
                # 게시글 선택
                post_options = {row['num']: f"#{row['num']} - {row['title']} (작성자: {row['name']})" for row in posts}
                selected_num = st.selectbox(
                    "삭제할 게시글 선택:", 
                    options=list(post_options.keys()),
                    format_func=lambda x: post_options[x]
                )
                
                if selected_num:
                    # 게시글 정보 표시
                    cursor = conn.cursor(dictionary=True)
                    cursor.execute(f"SELECT title, name, day FROM {board_type} WHERE num = %s", (selected_num,))
                    post_info = cursor.fetchone()
                    cursor.close()
                    
                    st.markdown("<hr>", unsafe_allow_html=True)
                    st.markdown(f"<h3>삭제할 게시글: {post_info['title']}</h3>", unsafe_allow_html=True)
                    st.markdown(f"<p><b>작성자:</b> {post_info['name']} | <b>작성일:</b> {post_info['day']}</p>", unsafe_allow_html=True)
                    st.markdown("<hr>", unsafe_allow_html=True)
                    
                    # 확인 및 비밀번호 입력
                    password = st.text_input("비밀번호 확인", type="password", placeholder="비밀번호를 입력하세요")
                    
                    col1, col2, col3 = st.columns([1, 1, 1])
                    with col2:
                        delete_button = st.button("🗑️ 게시글 삭제")
                    
                    if delete_button:
                        if password:
                            # 비밀번호 확인
                            cursor = conn.cursor()
                            cursor.execute(f"SELECT pass FROM {board_type} WHERE num = %s", (selected_num,))
                            stored_password = cursor.fetchone()[0]
                            
                            if password == stored_password:
                                # 최종 확인
                                st.warning("⚠️ 주의: 이 작업은 되돌릴 수 없습니다!")
                                confirm = st.checkbox("정말로 이 게시글을 삭제하시겠습니까?")
                                
                                if confirm:
                                    # 게시글 삭제
                                    delete_query = f"DELETE FROM {board_type} WHERE num = %s"
                                    cursor.execute(delete_query, (selected_num,))
                                    conn.commit()
                                    
                                    st.markdown('<div class="success-message">게시글이 성공적으로 삭제되었습니다!</div>', unsafe_allow_html=True)
                                    st.rerun()  # 페이지 새로고침
                            else:
                                st.markdown('<div class="error-message">비밀번호가 일치하지 않습니다.</div>', unsafe_allow_html=True)
                            
                            cursor.close()
                        else:
                            st.markdown('<div class="warning-message">비밀번호를 입력해주세요.</div>', unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)
            else:
                st.markdown('<div class="warning-message">삭제할 게시글이 없습니다.</div>', unsafe_allow_html=True)
            
            conn.close()
    except Exception as e:
        st.markdown(f'<div class="error-message">게시글 삭제 중 오류 발생: {str(e)}</div>', unsafe_allow_html=True)